// Roteamento simples com caminhos para arquivos HTML
const routes = {
    '#home': 'pages/home.html',
    '#about': 'pages/about.html',
    '#contact': 'pages/contact.html'
};

// Função para carregar conteúdo de arquivo HTML
function loadContent(page) {
    fetch(page)
        .then(response => {
            if (!response.ok) {
                throw new Error('pages/pageNotDefault.html');
            }
            return response.text();
        })
        .then(html => {
            document.getElementById('app').innerHTML = html;
        })
        .catch(error => {
            document.getElementById('app').innerHTML = 'pages/pageNotDefault.html';
        });
}

// Função para navegar entre as rotas
function navigate() {
    const hash = window.location.hash || '#home';
    const page = routes[hash] || 'pages/404.html';
    loadContent(page);
}

// Ouve a mudança no hash da URL
window.addEventListener('hashchange', navigate);

// Carrega a página inicial
window.addEventListener('load', navigate);











// aqui é da pagina contato
class CustomButton extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        const button = document.createElement('button');
        button.textContent = this.textContent;
        this.shadowRoot.appendChild(button);
    }
}

customElements.define('custom-button', CustomButton);

document.getElementById('auctionForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    const age = document.getElementById('age').value;
    const email = document.getElementById('email').value;
    const bid = document.getElementById('bid').value;
    console.log(`Nome: ${name}, Idade: ${age}, Email: ${email}, Valor do Lance: ${bid}`);
});






